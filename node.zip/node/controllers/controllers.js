exports.home = (req, res) => {
    res.render('home')
}


exports.about = (req, res) => {
    res.render('about')
}


exports.blog = (req, res) => {
    res.render('blog')
}

exports.login = (req, res) => {
    res.render('login')
}

exports.register = (req, res) => {
    res.render('register')
}

exports.postDetail = (req, res) => {
    res.render('postDetail')
}

exports.createPost = (req, res) => {
    res.render('createPost')
}

exports.savePost = (req, res) => {
    console.log(req.body)
}