const mysql = require('mysql2')

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'node_tranning'
})

con.connect((error) => {
    if (error) throw error
    console.log("Database connected sucessfully")
})